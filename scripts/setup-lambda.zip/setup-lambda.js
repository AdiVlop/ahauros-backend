/**
 * Complete Setup Lambda Function
 * Lambda pentru a crea schema completă a database-ului
 */

const { setupCompleteDatabase } = require('./complete-setup');

exports.handler = async (event, context) => {
  console.log('Complete Setup Lambda invoked:', JSON.stringify(event, null, 2));
  
  try {
    await setupCompleteDatabase();
    
    return {
      statusCode: 200,
      headers: {
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*'
      },
      body: JSON.stringify({
        success: true,
        message: 'Complete database schema created successfully!'
      })
    };
  } catch (error) {
    console.error('Setup error:', error);
    
    return {
      statusCode: 500,
      headers: {
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*'
      },
      body: JSON.stringify({
        success: false,
        error: error.message
      })
    };
  }
};
