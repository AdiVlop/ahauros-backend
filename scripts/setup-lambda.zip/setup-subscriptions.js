#!/usr/bin/env node

/**
 * Ahauros AI - Setup Subscriptions Table
 * Script pentru a crea tabela subscriptions în RDS PostgreSQL
 */

const { Client } = require('pg');

// SQL pentru crearea tabelului subscriptions
const createSubscriptionsTable = `
-- Ahauros AI - Subscriptions Schema
-- Tabela pentru stocarea abonamentelor Stripe

-- Creează tabela subscriptions
CREATE TABLE IF NOT EXISTS subscriptions (
    id SERIAL PRIMARY KEY,
    stripe_customer_id VARCHAR(255) NOT NULL,
    stripe_subscription_id VARCHAR(255) NOT NULL UNIQUE,
    email VARCHAR(255) NOT NULL,
    plan VARCHAR(50) NOT NULL, -- starter, growth, enterprise
    status VARCHAR(50) NOT NULL, -- active, canceled, past_due, incomplete, trialing
    current_period_start TIMESTAMP WITH TIME ZONE,
    current_period_end TIMESTAMP WITH TIME ZONE,
    trial_start TIMESTAMP WITH TIME ZONE,
    trial_end TIMESTAMP WITH TIME ZONE,
    cancel_at_period_end BOOLEAN DEFAULT FALSE,
    canceled_at TIMESTAMP WITH TIME ZONE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Indexes pentru performanță optimă
CREATE INDEX IF NOT EXISTS idx_subscriptions_customer ON subscriptions (stripe_customer_id);
CREATE INDEX IF NOT EXISTS idx_subscriptions_email ON subscriptions (email);
CREATE INDEX IF NOT EXISTS idx_subscriptions_status ON subscriptions (status);
CREATE INDEX IF NOT EXISTS idx_subscriptions_plan ON subscriptions (plan);
CREATE INDEX IF NOT EXISTS idx_subscriptions_created_at ON subscriptions (created_at);

-- Creează funcția pentru actualizarea updated_at
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$ language 'plpgsql';

-- Creează trigger pentru actualizarea automată a updated_at
DROP TRIGGER IF EXISTS update_subscriptions_updated_at ON subscriptions;
CREATE TRIGGER update_subscriptions_updated_at
    BEFORE UPDATE ON subscriptions
    FOR EACH ROW
    EXECUTE FUNCTION update_updated_at_column();

-- Creează view pentru abonamentele active
CREATE OR REPLACE VIEW active_subscriptions AS
SELECT 
    s.*,
    u.name as user_name,
    u.created_at as user_created_at
FROM subscriptions s
LEFT JOIN users u ON s.email = u.email
WHERE s.status IN ('active', 'trialing');

-- Creează view pentru statistici abonamente
CREATE OR REPLACE VIEW subscription_stats AS
SELECT 
    plan,
    status,
    COUNT(*) as count,
    COUNT(*) * CASE 
        WHEN plan = 'starter' THEN 199
        WHEN plan = 'growth' THEN 699
        WHEN plan = 'enterprise' THEN 1499
        ELSE 0
    END as monthly_revenue_eur
FROM subscriptions
GROUP BY plan, status;
`;

// SQL pentru inserarea datelor de test
const insertTestData = `
-- Inserează date de test (opțional)
INSERT INTO subscriptions (
    stripe_customer_id, 
    stripe_subscription_id, 
    email, 
    plan, 
    status, 
    current_period_start, 
    current_period_end
) VALUES 
(
    'cus_test_starter_001',
    'sub_test_starter_001',
    'test-starter@ahauros.io',
    'starter',
    'active',
    NOW(),
    NOW() + INTERVAL '1 month'
),
(
    'cus_test_growth_001',
    'sub_test_growth_001',
    'test-growth@ahauros.io',
    'growth',
    'active',
    NOW(),
    NOW() + INTERVAL '1 month'
),
(
    'cus_test_enterprise_001',
    'sub_test_enterprise_001',
    'test-enterprise@ahauros.io',
    'enterprise',
    'active',
    NOW(),
    NOW() + INTERVAL '1 month'
)
ON CONFLICT (stripe_subscription_id) DO NOTHING;
`;

async function setupSubscriptions() {
  const client = new Client({
    connectionString: process.env.DATABASE_URL,
    ssl: {
      rejectUnauthorized: false,
    },
  });

  try {
    console.log('🔌 Conectare la RDS PostgreSQL...');
    await client.connect();
    console.log('✅ Conectat la baza de date!');

    console.log('📋 Creare tabela subscriptions...');
    await client.query(createSubscriptionsTable);
    console.log('✅ Tabela subscriptions creată cu succes!');

    console.log('📊 Creare view-uri și funcții...');
    console.log('✅ View-uri și funcții create cu succes!');

    console.log('🧪 Inserare date de test...');
    await client.query(insertTestData);
    console.log('✅ Date de test inserate cu succes!');

    // Verifică rezultatul
    const result = await client.query('SELECT COUNT(*) as total_subscriptions FROM subscriptions');
    console.log(`📈 Total subscriptions în baza de date: ${result.rows[0].total_subscriptions}`);

    const stats = await client.query('SELECT * FROM subscription_stats');
    console.log('📊 Statistici abonamente:');
    stats.rows.forEach(row => {
      console.log(`  - ${row.plan} (${row.status}): ${row.count} abonamente, €${row.monthly_revenue_eur}/lună`);
    });

    console.log('🎉 Setup subscriptions completat cu succes!');

  } catch (error) {
    console.error('❌ Eroare la setup subscriptions:', error);
    throw error;
  } finally {
    await client.end();
  }
}

// Rulează scriptul dacă este apelat direct
if (require.main === module) {
  setupSubscriptions()
    .then(() => {
      console.log('✅ Script completat cu succes!');
      process.exit(0);
    })
    .catch((error) => {
      console.error('❌ Script eșuat:', error);
      process.exit(1);
    });
}

module.exports = { setupSubscriptions };

