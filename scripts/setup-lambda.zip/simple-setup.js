#!/usr/bin/env node

/**
 * Simple Database Setup
 * Creează doar tabelele de bază necesare
 */

const { Client } = require('pg');

// SQL pentru crearea tabelelor de bază
const createBasicTables = `
-- Creează tabela users
CREATE TABLE IF NOT EXISTS users (
    id SERIAL PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    email VARCHAR(255) UNIQUE NOT NULL,
    subscription_status VARCHAR(50) DEFAULT 'inactive',
    subscription_plan VARCHAR(50),
    stripe_customer_id VARCHAR(255),
    stripe_subscription_id VARCHAR(255),
    subscription_updated_at TIMESTAMP WITH TIME ZONE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- Creează tabela subscriptions
CREATE TABLE IF NOT EXISTS subscriptions (
    id SERIAL PRIMARY KEY,
    stripe_customer_id VARCHAR(255) NOT NULL,
    stripe_subscription_id VARCHAR(255) NOT NULL UNIQUE,
    email VARCHAR(255) NOT NULL,
    plan VARCHAR(50) NOT NULL,
    status VARCHAR(50) NOT NULL,
    current_period_start TIMESTAMP WITH TIME ZONE,
    current_period_end TIMESTAMP WITH TIME ZONE,
    trial_start TIMESTAMP WITH TIME ZONE,
    trial_end TIMESTAMP WITH TIME ZONE,
    cancel_at_period_end BOOLEAN DEFAULT FALSE,
    canceled_at TIMESTAMP WITH TIME ZONE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Creează indexuri
CREATE INDEX IF NOT EXISTS idx_users_email ON users(email);
CREATE INDEX IF NOT EXISTS idx_subscriptions_email ON subscriptions(email);
CREATE INDEX IF NOT EXISTS idx_subscriptions_status ON subscriptions(status);
`;

async function setupBasicTables() {
  const client = new Client({
    connectionString: process.env.DATABASE_URL,
    ssl: {
      rejectUnauthorized: false,
    },
  });

  try {
    console.log('🔌 Conectare la RDS PostgreSQL...');
    await client.connect();
    console.log('✅ Conectat la baza de date!');

    console.log('📋 Creare tabele de bază...');
    await client.query(createBasicTables);
    console.log('✅ Tabele create cu succes!');

    // Verifică tabelele
    const result = await client.query(`
      SELECT table_name 
      FROM information_schema.tables 
      WHERE table_schema = 'public' 
      ORDER BY table_name
    `);
    
    console.log('📊 Tabele existente:');
    result.rows.forEach(row => {
      console.log(`  - ${row.table_name}`);
    });

    console.log('🎉 Setup completat cu succes!');

  } catch (error) {
    console.error('❌ Eroare la setup:', error);
    throw error;
  } finally {
    await client.end();
  }
}

// Rulează scriptul dacă este apelat direct
if (require.main === module) {
  setupBasicTables()
    .then(() => {
      console.log('✅ Script completat cu succes!');
      process.exit(0);
    })
    .catch((error) => {
      console.error('❌ Script eșuat:', error);
      process.exit(1);
    });
}

module.exports = { setupBasicTables };
